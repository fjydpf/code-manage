$(document).ready(function() {
	$('.ui.dropdown')
		.dropdown()
		;
});

