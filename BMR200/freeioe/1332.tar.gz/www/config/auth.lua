return {
	realm = 'localhost',
	auth = 'skynet',
}
