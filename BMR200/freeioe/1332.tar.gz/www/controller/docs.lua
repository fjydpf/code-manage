return {
	get = function(self)
		lwf.render('docs.html', {})
	end
}
