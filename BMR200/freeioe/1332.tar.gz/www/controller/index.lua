return {
	get = function(self)
		lwf.render('index.html')
	end
}
