-- TODO: Rewrite needed
return function(self)
    self.template = require "resty.template"
end
