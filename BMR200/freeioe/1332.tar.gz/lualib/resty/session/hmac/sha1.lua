return ngx.hmac_sha1
