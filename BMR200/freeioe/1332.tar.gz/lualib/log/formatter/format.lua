local string = require "string"

local M = {}

function M.new() return string.format end

return M
