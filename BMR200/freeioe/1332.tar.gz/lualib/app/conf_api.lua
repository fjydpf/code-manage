local api = require 'app.conf.api'

return api
