local sc = require 'skynet.socketchannel'

return sc
